const https = require('https');
const fs = require('fs');
const path = require('path');

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    }).on('error', reject);
  });
}

async function verify() {
  const index = await fetchUrl('https://stocks360.web.app/index.html');
  const js = await fetchUrl('https://stocks360.web.app/js/stock-search.js?v=25');

  const check = {
    indexStatus: index.status,
    hasV25InIndex: index.body.includes('stock-search.js?v=25'),
    hasPopularPillsInIndex: index.body.includes('stock-quick-picks'),
    jsStatus: js.status,
    hasUnhideInJs: js.body.includes('stockResult.removeAttribute("hidden")'),
    hasDefaultFeaturedStock: js.body.includes('RELIANCE')
  };

  fs.writeFileSync(path.join(__dirname, 'verify-result.json'), JSON.stringify(check, null, 2), 'utf8');
  console.log('Verification done:', check);
}

verify();
