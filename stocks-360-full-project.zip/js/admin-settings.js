// admin-settings.js - Settings & Backup Management
document.addEventListener("DOMContentLoaded", function () {
  if (typeof AdminAuth !== "undefined") {
    AdminAuth.protectPage();
  }

  const currentUser = AdminAuth.getCurrentUser();
  const emailDisplay = document.getElementById("current-admin-email");
  if (emailDisplay && currentUser) {
    emailDisplay.textContent = currentUser.email;
  }

  // Gemini AI & Cost Control Settings
  const geminiForm = document.getElementById("gemini-settings-form");
  const geminiKeyInput = document.getElementById("gemini-api-key");
  const geminiModelSelect = document.getElementById("gemini-model-select");
  const geminiDailyLimitInput = document.getElementById("gemini-daily-limit");
  const geminiUsageSummary = document.getElementById("gemini-usage-summary");
  const geminiFeedback = document.getElementById("gemini-settings-feedback");

  if (typeof StocksGeminiAI !== "undefined") {
    StocksGeminiAI.loadConfig().then(function (cfg) {
      if (geminiKeyInput && cfg.apiKey) geminiKeyInput.value = cfg.apiKey;
      if (geminiModelSelect && cfg.model) geminiModelSelect.value = cfg.model;
      if (geminiDailyLimitInput && cfg.dailyLimit) geminiDailyLimitInput.value = cfg.dailyLimit;
    });

    const stats = StocksGeminiAI.getUsageStats();
    if (geminiUsageSummary) {
      geminiUsageSummary.textContent = `Today's Usage (${stats.date}): ${stats.requests} API requests • ${stats.cacheHits} Free Cache Hits`;
    }
  }

  if (geminiForm && typeof StocksGeminiAI !== "undefined") {
    geminiForm.addEventListener("submit", function (e) {
      e.preventDefault();
      StocksGeminiAI.saveConfig({
        apiKey: geminiKeyInput ? geminiKeyInput.value.trim() : "",
        model: geminiModelSelect ? geminiModelSelect.value : "gemini-3.5-flash-lite",
        dailyLimit: geminiDailyLimitInput ? parseInt(geminiDailyLimitInput.value, 10) || 500 : 500
      });
      showFeedback(
        geminiFeedback,
        "Gemini AI model & daily cost guardrails saved and synced!",
        "success"
      );
    });
  }

  // Password Change Form
  const passForm = document.getElementById("change-password-form");
  const passMsg = document.getElementById("password-feedback");

  if (passForm) {
    passForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const currentPass = document.getElementById("current-password").value;
      const newPass = document.getElementById("new-password").value;
      const confirmPass = document.getElementById("confirm-new-password").value;

      if (newPass !== confirmPass) {
        showFeedback(passMsg, "New passwords do not match.", "error");
        return;
      }

      if (!currentUser) {
        showFeedback(passMsg, "No active session found.", "error");
        return;
      }

      const res = AdminAuth.changePassword(currentUser.email, currentPass, newPass);
      if (res.success) {
        showFeedback(passMsg, res.message, "success");
        passForm.reset();
      } else {
        showFeedback(passMsg, res.message, "error");
      }
    });
  }

  // Backup Export
  const exportBtn = document.getElementById("export-backup-btn");
  if (exportBtn) {
    exportBtn.addEventListener("click", function () {
      const backupData = StocksDataStore.exportBackup();
      const blob = new Blob([backupData], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `stocks360-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // Backup Import
  const importInput = document.getElementById("import-file-input");
  const importBtn = document.getElementById("import-backup-btn");
  const importMsg = document.getElementById("import-feedback");

  if (importBtn && importInput) {
    importBtn.addEventListener("click", function () {
      importInput.click();
    });

    importInput.addEventListener("change", function (e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function (evt) {
        const content = evt.target.result;
        const res = StocksDataStore.importBackup(content);
        if (res.success) {
          showFeedback(importMsg, "Website database restored successfully! Reloading in 1s...", "success");
          setTimeout(() => location.reload(), 1200);
        } else {
          showFeedback(importMsg, "Import failed: " + res.error, "error");
        }
      };
      reader.readAsText(file);
    });
  }

  // Reset to Default
  const resetBtn = document.getElementById("reset-default-btn");
  if (resetBtn) {
    resetBtn.addEventListener("click", function () {
      if (confirm("Reset all website articles and lessons back to default demo data?")) {
        StocksDataStore.resetToDefault();
        alert("Website restored to default data. Reloading page.");
        location.reload();
      }
    });
  }

  // Metrics update
  const newsCount = document.getElementById("metric-news-count");
  const nlCount = document.getElementById("metric-nl-count");
  const unitCount = document.getElementById("metric-unit-count");

  if (newsCount) newsCount.textContent = StocksDataStore.getNews().length;
  if (nlCount) nlCount.textContent = StocksDataStore.getNewsletters().length;
  if (unitCount) unitCount.textContent = StocksDataStore.getUnits().length;

  // Database Mode status update
  const dbModeVal = document.getElementById("metric-db-mode");
  const dbModeSub = document.getElementById("metric-db-sub");
  if (dbModeVal) {
    if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
      dbModeVal.textContent = "Cloud Active";
      dbModeVal.style.color = "#16a34a";
      if (dbModeSub) dbModeSub.textContent = "Firestore Real-Time Sync";
    } else {
      dbModeVal.textContent = "Local Cache";
      dbModeVal.style.color = "#0284c7";
      if (dbModeSub) dbModeSub.textContent = "High-Speed Offline Fallback";
    }
  }

  function showFeedback(el, message, type) {
    if (!el) return;
    el.textContent = message;
    el.className = `feedback-box ${type}`;
    el.hidden = false;
  }
});
