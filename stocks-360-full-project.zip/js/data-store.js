/**
 * Stocks 360 - Unified Data Store (data-store.js)
 * Manages persistence for News, Newsletters, Learning Units, Comments/Inquiries, and Site Settings.
 * Supports:
 * 1. Google Cloud Firebase Firestore (Real-time cloud database across all devices)
 * 2. High-speed local cache & seed data fallback
 */

const StocksDataStore = (function () {
  const STORAGE_KEYS = {
    NEWS: "stocks360_news_data",
    NEWSLETTERS: "stocks360_newsletter_data",
    LEARN_UNITS: "stocks360_learn_units",
    COMMENTS: "stocks360_comments",
    SITE_SETTINGS: "stocks360_site_settings"
  };

  const SEED_NEWS = [
    {
      id: "news-1",
      title: "Indian markets show mixed performance this week",
      author: "Rahul Sharma",
      published: "27 Oct 2026, 10:30 AM",
      publishedAt: 1793163600000,
      synopsis: "Banking and IT sectors remained in focus as markets moved in a narrow range during the week.",
      content: "Indian stock markets showed mixed performance this week. Banking and IT sectors remained in focus as markets moved in a narrow range. Investors stayed cautious ahead of important economic data. Overall sentiment remained balanced with selective buying in quality stocks.",
      glossary: "Volatility: The degree of variation in trading prices. Sensex: Benchmark index of BSE.",
      keywords: "markets, banking, IT, performance",
      category: "Market Update",
      audioVoiceLang: "en-IN",
      hasCompressedAudio: true
    },
    {
      id: "news-2",
      title: "Global cues continue to influence market sentiment",
      author: "Meenugula Gowrishankar",
      published: "26 Oct 2026, 4:15 PM",
      publishedAt: 1793097900000,
      synopsis: "International developments and global indices guide domestic market movements.",
      content: "Global cues and domestic economic data continued to influence market sentiment. International developments and movements in global markets played an important role in shaping investor mood. Analysts noted that short-term fluctuations remain in line with broader macroeconomic trends and quarterly earnings expectations.",
      glossary: "Global Cues: Signals from international financial markets such as US, Europe, and Asia.",
      keywords: "global cues, sentiment, markets",
      category: "Global Economy",
      audioVoiceLang: "en-IN",
      hasCompressedAudio: true
    },
    {
      id: "news-3",
      title: "Mid-cap and banking stocks witness steady institutional activity",
      author: "Priya Nair",
      published: "25 Oct 2026, 11:00 AM",
      publishedAt: 1793002200000,
      synopsis: "Domestic institutional flows supported key sectoral indices amid steady quarterly results.",
      content: "Domestic institutional investors remained net buyers across banking, capital goods, and technology counters this session. Market breadth stayed balanced as quarterly corporate earnings and macroeconomic indicators guided trading volumes across major exchanges.",
      glossary: "Institutional Investors: Organizations such as mutual funds and insurance companies that invest large sums in the market. Market Breadth: Comparison of the number of advancing stocks to declining stocks.",
      keywords: "institutional activity, banking, mid-cap, earnings",
      category: "Market Update",
      audioVoiceLang: "en-IN",
      hasCompressedAudio: true
    }
  ];

  const SEED_NEWSLETTERS = [
    {
      id: "nl-1",
      title: "Weekly Market Overview - 27 Oct 2026",
      author: "Rahul Sharma",
      published: "27 Oct 2026, 10:00 AM",
      content: "This week the market showed mixed trends. Major indices moved in a narrow range. Banking and IT sectors remained active. Global cues had a moderate impact on investor sentiment. Domestic institutional flows and upcoming corporate earnings announcements are expected to set the direction for the coming week.",
      glossary: "Index: A group of stocks that represent a section of the market. Sentiment: Overall mood of market participants.",
      keywords: "weekly overview, markets, banking, IT"
    },
    {
      id: "nl-2",
      title: "Weekly Market Overview - 20 Oct 2026",
      author: "Priya Nair",
      published: "20 Oct 2026, 10:00 AM",
      content: "Markets remained cautious during the week. Investors waited for important economic data. Selective buying was seen in a few quality stocks. Sectoral rotation into defensive and large-cap counters remained the key theme through the week.",
      glossary: "",
      keywords: "markets, cautious, economic data"
    },
    {
      id: "nl-3",
      title: "Weekly Market Overview - 13 Oct 2026",
      author: "Meenugula Gowrishankar",
      published: "13 Oct 2026, 10:00 AM",
      content: "The week started on a positive note but later saw some profit booking. Overall, the market remained range-bound. Market participants closely tracked central bank policy commentary, crude oil prices, and global bond yields.",
      glossary: "Profit booking: Selling stocks after a rise in price to lock gains.",
      keywords: "range-bound, profit booking, market overview"
    }
  ];

  const SEED_UNITS = [
    {
      id: "unit-1",
      title: "Unit 1: Introduction to Stock Markets",
      description: "Basics of financial markets, reasons to invest, and primary regulators.",
      subunits: [
        {
          id: "su-1",
          title: "1. Why Stock Market?",
          body: "The stock market allows companies to raise money by selling shares to the public. It also gives people a chance to own a small part of companies and benefit from their growth over time.",
          takeaways: "Stock market helps companies raise capital. Investors can become part owners of companies."
        },
        {
          id: "su-2",
          title: "2. The Regulators of the Stock Market",
          body: "In India, SEBI (Securities and Exchange Board of India) is the main regulator of the stock market. It protects investors and ensures fair practices.",
          takeaways: "SEBI regulates the Indian stock market. Regulation helps maintain trust and fairness."
        }
      ]
    },
    {
      id: "unit-2",
      title: "Unit 2: Understanding Market Participants",
      description: "Learn about retail investors, institutions, domestic players, and brokers.",
      subunits: [
        {
          id: "su-3",
          title: "1. Who are the Investors?",
          body: "Investors are individuals or institutions who buy shares with the aim of earning returns over a period of time. They can be retail investors or large institutional investors.",
          takeaways: "There are retail and institutional investors. Different investors have different goals and time horizons."
        }
      ]
    }
  ];

  const SEED_COMMENTS = [
    {
      id: "cmt-1",
      lessonId: "su-1",
      badge: "Learn • Unit 1",
      name: "Rahul S.",
      text: "Can you explain the difference between primary market (IPO) and secondary market in simple words?",
      reply: "",
      date: "28 Oct 2026, 11:45 AM",
      createdAt: 1793210700000
    },
    {
      id: "cmt-2",
      lessonId: "ask360",
      badge: "Stocks 360 AI Query",
      name: "Ananya Verma",
      text: "How does inflation affect the stock market prices of banking stocks?",
      reply: "",
      date: "27 Oct 2026, 3:20 PM",
      createdAt: 1793137200000
    }
  ];

  function getItem(key, fallback) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function setItem(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  }

  function emitSync(collection) {
    if (typeof window !== "undefined" && typeof window.dispatchEvent === "function") {
      window.dispatchEvent(new CustomEvent("stocks360:sync", { detail: { collection: collection } }));
    }
  }

  function init() {
    const rawNews = localStorage.getItem(STORAGE_KEYS.NEWS);
    if (!rawNews || rawNews.includes("Learners should understand") || rawNews.includes("Understanding market volatility in simple terms")) {
      setItem(STORAGE_KEYS.NEWS, SEED_NEWS);
    }
    const rawNL = localStorage.getItem(STORAGE_KEYS.NEWSLETTERS);
    if (!rawNL || rawNL.includes("Learners are advised") || rawNL.includes("Educational focus should remain")) {
      setItem(STORAGE_KEYS.NEWSLETTERS, SEED_NEWSLETTERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.LEARN_UNITS)) {
      setItem(STORAGE_KEYS.LEARN_UNITS, SEED_UNITS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.COMMENTS)) {
      setItem(STORAGE_KEYS.COMMENTS, SEED_COMMENTS);
    }

    syncWithFirebase();
  }

  function syncWithFirebase() {
    if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
      const db = StocksFirebase.getDb();

      // 1. News real-time listener
      db.collection("news").onSnapshot(snapshot => {
        if (!snapshot.empty) {
          const cloudNews = [];
          snapshot.forEach(doc => cloudNews.push(doc.data()));
          cloudNews.sort((a, b) => (b.publishedAt || 0) - (a.publishedAt || 0));
          setItem(STORAGE_KEYS.NEWS, cloudNews);
          emitSync("news");
        }
      }, err => console.log("Firebase news sync note:", err.message));

      // 2. Newsletters real-time listener
      db.collection("newsletters").onSnapshot(snapshot => {
        if (!snapshot.empty) {
          const cloudNL = [];
          snapshot.forEach(doc => cloudNL.push(doc.data()));
          setItem(STORAGE_KEYS.NEWSLETTERS, cloudNL);
          emitSync("newsletters");
        }
      }, err => console.log("Firebase newsletters sync note:", err.message));

      // 3. Learn units real-time listener
      db.collection("learn_units").onSnapshot(snapshot => {
        if (!snapshot.empty) {
          const cloudUnits = [];
          snapshot.forEach(doc => cloudUnits.push(doc.data()));
          setItem(STORAGE_KEYS.LEARN_UNITS, cloudUnits);
          emitSync("learn_units");
        }
      }, err => console.log("Firebase learn_units sync note:", err.message));

      // 4. Comments & Ask inquiries real-time listener
      db.collection("comments").onSnapshot(snapshot => {
        if (!snapshot.empty) {
          const cloudComments = [];
          snapshot.forEach(doc => cloudComments.push(doc.data()));
          cloudComments.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
          setItem(STORAGE_KEYS.COMMENTS, cloudComments);
          emitSync("comments");
        }
      }, err => console.log("Firebase comments sync note:", err.message));

      // 5. Site settings (About Us & Contact details) real-time listener
      db.collection("site_settings").doc("main").onSnapshot(doc => {
        if (doc.exists) {
          const data = doc.data() || {};
          if (data.aboutContent) localStorage.setItem("stocks360_about_content", data.aboutContent);
          if (data.contactEmail) localStorage.setItem("stocks360_contact_email", data.contactEmail);
          if (data.contactPhone) localStorage.setItem("stocks360_contact_phone", data.contactPhone);
          if (data.contactHours) localStorage.setItem("stocks360_contact_hours", data.contactHours);
          emitSync("site_settings");
        }
      }, err => console.log("Firebase site_settings sync note:", err.message));
    }
  }

  init();

  return {
    // ---------------- NEWS API ----------------
    getNews: function () {
      return getItem(STORAGE_KEYS.NEWS, SEED_NEWS);
    },

    getNewsById: function (id) {
      const allNews = this.getNews();
      return allNews.find(item => item.id === id) || null;
    },

    saveNews: function (article) {
      const allNews = this.getNews();
      const newArticle = {
        id: article.id || "news-" + Date.now(),
        title: article.title || "Untitled News",
        author: article.author || "Stocks 360 Editorial",
        published: article.published || new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }),
        publishedAt: article.publishedAt || Date.now(),
        synopsis: article.synopsis || "",
        content: article.content || "",
        glossary: article.glossary || "",
        keywords: article.keywords || "",
        category: article.category || "General",
        audioUrl: article.audioUrl || "",
        audioVoiceLang: article.audioVoiceLang || "en-IN",
        hasCompressedAudio: article.hasCompressedAudio !== undefined ? article.hasCompressedAudio : true,
        audioSizeKb: article.audioSizeKb || ""
      };

      const existingIdx = allNews.findIndex(n => n.id === newArticle.id);
      if (existingIdx >= 0) {
        allNews[existingIdx] = newArticle;
      } else {
        allNews.unshift(newArticle);
      }

      setItem(STORAGE_KEYS.NEWS, allNews);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("news").doc(newArticle.id).set(newArticle)
          .catch(err => console.error("Firebase write error:", err));
      }

      return newArticle;
    },

    deleteNews: function (id) {
      let allNews = this.getNews();
      allNews = allNews.filter(n => n.id !== id);
      setItem(STORAGE_KEYS.NEWS, allNews);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("news").doc(id).delete()
          .catch(err => console.error("Firebase delete error:", err));
        StocksFirebase.getDb().collection("site_settings").doc("audio_" + id).delete()
          .catch(() => {});
      }
      return true;
    },

    // ---------------- NEWSLETTERS API ----------------
    getNewsletters: function () {
      return getItem(STORAGE_KEYS.NEWSLETTERS, SEED_NEWSLETTERS);
    },

    getNewsletterById: function (id) {
      const all = this.getNewsletters();
      return all.find(item => item.id === id) || null;
    },

    saveNewsletter: function (nl) {
      const all = this.getNewsletters();
      const newNl = {
        id: nl.id || "nl-" + Date.now(),
        title: nl.title || "Weekly Market Overview",
        author: nl.author || "Stocks 360 Research",
        published: nl.published || new Date().toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }),
        content: nl.content || "",
        glossary: nl.glossary || "",
        keywords: nl.keywords || ""
      };

      const existingIdx = all.findIndex(n => n.id === newNl.id);
      if (existingIdx >= 0) {
        all[existingIdx] = newNl;
      } else {
        all.unshift(newNl);
      }

      setItem(STORAGE_KEYS.NEWSLETTERS, all);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("newsletters").doc(newNl.id).set(newNl)
          .catch(err => console.error("Firebase write error:", err));
      }

      return newNl;
    },

    deleteNewsletter: function (id) {
      let all = this.getNewsletters();
      all = all.filter(n => n.id !== id);
      setItem(STORAGE_KEYS.NEWSLETTERS, all);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("newsletters").doc(id).delete()
          .catch(err => console.error("Firebase delete error:", err));
      }
      return true;
    },

    // ---------------- LEARN UNITS API ----------------
    getUnits: function () {
      return getItem(STORAGE_KEYS.LEARN_UNITS, SEED_UNITS);
    },

    getUnitById: function (unitId) {
      const units = this.getUnits();
      return units.find(u => u.id === unitId) || null;
    },

    saveUnit: function (unit) {
      const units = this.getUnits();
      const newUnit = {
        id: unit.id || "unit-" + (units.length + 1),
        title: unit.title || "Untitled Unit",
        description: unit.description || "",
        subunits: unit.subunits || []
      };

      const existingIdx = units.findIndex(u => u.id === newUnit.id);
      if (existingIdx >= 0) {
        units[existingIdx] = newUnit;
      } else {
        units.push(newUnit);
      }

      setItem(STORAGE_KEYS.LEARN_UNITS, units);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("learn_units").doc(newUnit.id).set(newUnit)
          .catch(err => console.error("Firebase write error:", err));
      }

      return newUnit;
    },

    deleteUnit: function (unitId) {
      let units = this.getUnits();
      units = units.filter(u => u.id !== unitId);
      setItem(STORAGE_KEYS.LEARN_UNITS, units);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("learn_units").doc(unitId).delete()
          .catch(err => console.error("Firebase delete error:", err));
      }
      return true;
    },

    saveSubunit: function (unitId, subunit) {
      const units = this.getUnits();
      const targetUnit = units.find(u => u.id === unitId);
      if (!targetUnit) return null;

      if (!targetUnit.subunits) targetUnit.subunits = [];

      const newSubunit = {
        id: subunit.id || "su-" + Date.now(),
        title: subunit.title,
        body: subunit.body,
        takeaways: subunit.takeaways || ""
      };

      const existingIdx = targetUnit.subunits.findIndex(s => s.id === newSubunit.id);
      if (existingIdx >= 0) {
        targetUnit.subunits[existingIdx] = newSubunit;
      } else {
        targetUnit.subunits.push(newSubunit);
      }

      setItem(STORAGE_KEYS.LEARN_UNITS, units);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("learn_units").doc(targetUnit.id).set(targetUnit)
          .catch(err => console.error("Firebase write error:", err));
      }

      return newSubunit;
    },

    // ---------------- COMMENTS & INQUIRIES API ----------------
    getComments: function (lessonId) {
      const all = getItem(STORAGE_KEYS.COMMENTS, SEED_COMMENTS);
      if (!lessonId) return all;
      return all.filter(c => c.lessonId === lessonId);
    },

    saveComment: function (comment) {
      const all = getItem(STORAGE_KEYS.COMMENTS, SEED_COMMENTS);
      const item = {
        id: comment.id || "cmt-" + Date.now(),
        lessonId: comment.lessonId || "ask360",
        badge: comment.badge || "Learner Question",
        name: comment.name || "Learner",
        text: comment.text || "",
        reply: comment.reply || "",
        date: comment.date || new Date().toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" }),
        createdAt: comment.createdAt || Date.now()
      };

      const idx = all.findIndex(c => c.id === item.id);
      if (idx >= 0) {
        all[idx] = item;
      } else {
        all.unshift(item);
      }
      setItem(STORAGE_KEYS.COMMENTS, all);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("comments").doc(item.id).set(item)
          .catch(err => console.error("Firebase comment write error:", err));
      }
      return item;
    },

    deleteComment: function (id) {
      let all = getItem(STORAGE_KEYS.COMMENTS, SEED_COMMENTS);
      all = all.filter(c => c.id !== id);
      setItem(STORAGE_KEYS.COMMENTS, all);

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("comments").doc(id).delete()
          .catch(err => console.error("Firebase comment delete error:", err));
      }
      return true;
    },

    // ---------------- SITE SETTINGS API (ABOUT & CONTACT) ----------------
    saveSiteSettings: function (partialSettings) {
      if (partialSettings.aboutContent !== undefined) {
        localStorage.setItem("stocks360_about_content", partialSettings.aboutContent);
      }
      if (partialSettings.contactEmail !== undefined) {
        localStorage.setItem("stocks360_contact_email", partialSettings.contactEmail);
      }
      if (partialSettings.contactPhone !== undefined) {
        localStorage.setItem("stocks360_contact_phone", partialSettings.contactPhone);
      }
      if (partialSettings.contactHours !== undefined) {
        localStorage.setItem("stocks360_contact_hours", partialSettings.contactHours);
      }

      if (typeof StocksFirebase !== "undefined" && StocksFirebase.isReady()) {
        StocksFirebase.getDb().collection("site_settings").doc("main").set(partialSettings, { merge: true })
          .catch(err => console.error("Firebase settings write error:", err));
      }
    },

    // ---------------- BACKUP & RESTORE ----------------
    exportBackup: function () {
      const payload = {
        version: "1.0",
        exportedAt: new Date().toISOString(),
        news: this.getNews(),
        newsletters: this.getNewsletters(),
        units: this.getUnits(),
        comments: this.getComments()
      };
      return JSON.stringify(payload, null, 2);
    },

    importBackup: function (jsonString) {
      try {
        const payload = JSON.parse(jsonString);
        if (payload.news) setItem(STORAGE_KEYS.NEWS, payload.news);
        if (payload.newsletters) setItem(STORAGE_KEYS.NEWSLETTERS, payload.newsletters);
        if (payload.units) setItem(STORAGE_KEYS.LEARN_UNITS, payload.units);
        if (payload.comments) setItem(STORAGE_KEYS.COMMENTS, payload.comments);
        return { success: true };
      } catch (err) {
        return { success: false, error: err.message };
      }
    },

    resetToDefault: function () {
      setItem(STORAGE_KEYS.NEWS, SEED_NEWS);
      setItem(STORAGE_KEYS.NEWSLETTERS, SEED_NEWSLETTERS);
      setItem(STORAGE_KEYS.LEARN_UNITS, SEED_UNITS);
      setItem(STORAGE_KEYS.COMMENTS, SEED_COMMENTS);
    }
  };
})();

if (typeof window !== "undefined") {
  window.StocksDataStore = StocksDataStore;
}
